﻿function fail() {
    alert("Thông tin sai");
}



function ThongbaoDatHang() {
    alert("Đặt hàng Thành công");
    }
